from flask import Flask, request, jsonify, render_template
import requests
import cohere

# Initialize the app
app = Flask(__name__)

# Cohere API setup
co = cohere.Client('')  # Replace with your Cohere API Key

# YouTube API setup
YOUTUBE_API_KEY = ''

# Telegram Bot setup
TELEGRAM_BOT_TOKEN = ''  # Replace with your Telegram Bot Token

# Function to analyze sentiment using Cohere
def analyze_sentiment(mood, stress_level):
    print("Analyzing sentiment...")

    # Analyze mood
    mood_response = co.generate(
        model='command-xlarge-nightly',
        prompt=f"Analyze this mood and determine its sentiment: {mood}\nOutput: Provide a detailed analysis.",
        max_tokens=50,
        temperature=0.5
    )
    mood_sentiment = mood_response.generations[0].text.strip()

    # Analyze stress level
    stress_response = co.generate(
        model='command-xlarge-nightly',
        prompt=f"Analyze this stress level and determine its sentiment: {stress_level}\nOutput: Provide a detailed analysis.",
        max_tokens=50,
        temperature=0.5
    )
    stress_sentiment = stress_response.generations[0].text.strip()

    # Combine the results from mood and stress sentiment
    combined_sentiment = f"Mood Sentiment: {mood_sentiment}\nStress Sentiment: {stress_sentiment}"
    print(f"Combined Sentiment: {combined_sentiment}")

    # Generate a summary of the combined sentiment
    summary_response = co.generate(
        model='command-xlarge-nightly',
        prompt=f"Read the following sentiment analysis and give an optimistic reply in 2 to 3 words:\n\n{combined_sentiment}\n\nOutput:",
        max_tokens=5,
        temperature=0.5
    )
    summary = summary_response.generations[0].text.strip()

    # Rate the critical condition from 1 to 10
    rating_response = co.generate(
        model='command-xlarge-nightly',
       prompt = f"""
Based on the following sentiment analysis, rate the critical condition of the user on a scale from 1 to 10, where:

1 - Extremely positive, calm, and balanced (Mood: Calm, Stress Level: Very Low)
2 - Very positive, relaxed, and content (Mood: Happy, Stress Level: Low)
3 - Positive, feeling good but slightly stressed (Mood: Hopeful, Stress Level: Medium)
4 - Somewhat positive, mild stress or tension (Mood: Excited, Stress Level: Medium)
5 - Neutral, neither very positive nor negative, no immediate concerns (Mood: Neutral, Stress Level: Low)
6 - Slightly negative, feeling some stress or anxiety (Mood: Anxious, Stress Level: High)
7 - Moderately negative, feeling stressed or anxious (Mood: Lonely, Stress Level: Very High)
8 - Negative, feeling sad, overwhelmed, or distressed (Mood: Sad, Stress Level: Overwhelmed)
9 - Very negative, feeling very sad, anxious, or unable to cope (Mood: Depressed, Stress Level: Very High)
10 - Extremely negative, sad, overwhelmed, or in immediate need of help (Mood: Hopeless/Grief-stricken, Stress Level: Overwhelmed)

Sentiment: {combined_sentiment}

Rate the user's critical condition from 1 to 10 based on the sentiment provided above. Output:
"""
,
        max_tokens=5,
        temperature=0.5
    )
    try:
        rate = int(rating_response.generations[0].text.strip())
        print(f"Rate: {rate}")
    except ValueError:
        rate = 5  # Default to 1 if parsing fails
    print(f"Rate: {rate}")

    return combined_sentiment, summary, rate

# Function to send a Telegram message
def send_telegram_message(chat_id, message):
    print(f"Sending Telegram message to chat ID: {chat_id}...")
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'HTML'  # Supports basic HTML formatting
    }
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        print("Message sent successfully.")
    else:
        print(f"Failed to send message. Status code: {response.status_code}")
    return response.status_code == 200

# Function to fetch YouTube videos
def get_youtube_videos(query, max_results):
    url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q={query}&type=video&maxResults={max_results}&key={YOUTUBE_API_KEY}"
    response = requests.get(url)
    if response.status_code != 200:
        return []
    results = response.json().get('items', [])
    videos = [
        {
            'title': item['snippet']['title'],
            'videoId': item['id']['videoId']  # Include videoId for embedding
        }
        for item in results if 'id' in item and 'videoId' in item['id']
    ]
    print("Videos fetched:", videos)
    return videos

# Route to handle Google Form webhook (MCQ-based journaling)
@app.route('/form_submission', methods=['POST'])
def form_submission():
    """
    Receive and handle form data for sentiment analysis.
    """
    print("Form submission received...")

    # Parse JSON data from the request
    form_data = request.get_json()
    mood = form_data.get('mood')
    stress_level = form_data.get('stress_level')
    chat_id = form_data.get('chat_id')

    print(f"Received data - Mood: {mood}, Stress Level: {stress_level}, Chat ID: {chat_id}")

    if not chat_id:
        print("Error: No chat ID provided.")
        return jsonify({'error': 'No chat ID provided.'}), 400

    # Handle form data to detect sentiment
    combined_sentiment, summary, rate = analyze_sentiment(mood, stress_level)
    print(f"Detected sentiment: {combined_sentiment}, Summary: {summary}, Rate: {rate}")

    # Send alerts based on the rating
    if rate > 5:
        print("Critical condition detected. Sending alert to parents...")
        alert_message = f"🚨 <b>Critical Alert:</b> The user's condition is rated as <b>{rate}/10</b>. \n\n <b>{combined_sentiment}</b>.\n\nImmediate attention is needed!!!"
        send_telegram_message(chat_id, alert_message)

    # Fetch recommended YouTube videos using the summary as the query
    recommended_videos = get_youtube_videos(summary, 3)

    return jsonify({
        'sentiment': combined_sentiment,
        'summary': summary,
        'rate': rate,
        'recommended_videos': recommended_videos
    })

# Route to render the Google Form (assumed to be a separate page in this case)
@app.route('/')
def home():
    print("Rendering Google Form...")
    return render_template('index.html')  # Make sure your Google Form is embedded here or link to it directly

# Run the app
if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)
